# CLUCKNORRIS Website

This is a ready-to-deploy static website for **$CLUCKNORRIS**.

## What's included

- `index.html` - landing page
- `styles.css` - styling
- `script.js` - small JS for menu + copy
- `assets/hero.png` - hero image
- `assets/logo.png` - navbar/footer logo

## How to deploy

1. Upload the repository to GitHub.
2. Replace `assets/logo.png` and `assets/hero.png` with your real images (keep filenames).
3. Edit `index.html` to update `YOUR_CONTRACT_ADDRESS_HERE` with the real contract address.
4. Optional: Edit `script.js` to update links.

### One-click Netlify deploy
After you push to GitHub, replace `YOUR-USERNAME` in the button below with your GitHub username and click:

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/YOUR-USERNAME/CLUCKNORRIS)


## Notes
- Raydium button already points to https://raydium.io/
- Social links point to the Telegram and Twitter you provided.
- Contract address is left for you to insert later.
