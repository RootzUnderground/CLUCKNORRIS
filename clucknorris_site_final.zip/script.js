// Mobile nav toggle
const burger = document.querySelector('.burger');
const nav = document.querySelector('.nav');
if (burger) {
  burger.addEventListener('click', () => {
    nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
  });
}

// Smooth copy button
document.querySelectorAll('.copy').forEach(btn => {
  btn.addEventListener('click', () => {
    const sel = btn.getAttribute('data-copy');
    const el = document.querySelector(sel);
    if (!el) return;
    navigator.clipboard.writeText(el.textContent.trim());
    btn.textContent = 'Copied!';
    setTimeout(() => (btn.textContent = 'Copy'), 1200);
  });
});

// CTA link placeholders
const BUY_URL = 'https://raydium.io/';         
const COMMUNITY_URL = 'https://t.me/+nA9AaK90bpU3YzNl';   
document.getElementById('buy').href = BUY_URL;
document.getElementById('buy-cta').href = BUY_URL;
document.getElementById('community') && (document.getElementById('community').href = COMMUNITY_URL);